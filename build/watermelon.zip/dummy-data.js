var dummy_data = [
  {
    chat_group: "KaiOs",
    DocumentList: [
      {
        user: "ivan",
        message: "blabla",
      },
      {
        user: "per",
        message: "hello world",
      },
    ],
  },
  {
    chat_group: "bHackers",
    DocumentList: [
      {
        user: "perry",
        message: "hey",
      },
      {
        user: "northman",
        message: "wuha",
      },
    ],
  },
];
