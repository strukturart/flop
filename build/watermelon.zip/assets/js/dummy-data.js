"use strict";

export const dummy_data = [
  {
    chat_group: "KaiOs",
    DocumentList: [
      {
        user: "ivan",
        message: "hello",
        time: 1607110465663,
        read: false,
      },
      {
        user: "per",
        message: "hello world",
        time: 1607110465663,
        read: true,
      },
    ],
  },
  {
    chat_group: "bHackers",
    DocumentList: [
      {
        user: "perry",
        message: "hey",
        time: 1607110465663,
        read: false,
      },
      {
        user: "northman",
        message: "hey you",
        time: 1651756417,
        read: false,
      },
    ],
  },

  {
    chat_group: "chaos",
    DocumentList: [
      {
        user: "perry",
        message: "hey",
        time: 1607110465663,
        read: false,
      },
      {
        user: "northman",
        message: "hey you",
        time: 1607110465663,
        read: false,
      },
    ],
  },
];
