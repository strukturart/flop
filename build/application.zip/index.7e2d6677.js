const dummy_data = [
    {
        chat_group: "KaiOs",
        DocumentList: [
            {
                user: "ivan",
                message: "hello"
            },
            {
                user: "per",
                message: "hello world"
            }, 
        ]
    },
    {
        chat_group: "bHackers",
        DocumentList: [
            {
                user: "perry",
                message: "hey"
            },
            {
                user: "northman",
                message: "hey you"
            }, 
        ]
    },
    {
        chat_group: "chaos",
        DocumentList: [
            {
                user: "perry",
                message: "hey"
            },
            {
                user: "northman",
                message: "hey you"
            }, 
        ]
    }, 
];

